import React from 'react';
import { User, MapPin, Calendar, Heart } from 'lucide-react';

const About: React.FC = () => {
  return (
    <section id="about" className="py-20 bg-white">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl sm:text-5xl font-bold text-slate-800 mb-4">
              About Me
            </h2>
            <div className="w-24 h-1 bg-gradient-to-r from-blue-600 to-purple-600 mx-auto rounded-full"></div>
          </div>

          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div className="space-y-6">
              <div className="bg-gradient-to-br from-blue-50 to-purple-50 p-8 rounded-2xl shadow-lg">
                <div className="flex items-center gap-3 mb-4">
                  <User className="h-6 w-6 text-blue-600" />
                  <h3 className="text-xl font-semibold text-slate-800">Who I Am</h3>
                </div>
                <p className="text-slate-600 leading-relaxed">
                  I'm Pankaj Upadhyay, a passionate full stack developer with expertise in modern web
                  technologies. I love creating digital solutions that make a difference and
                  bring ideas to life through clean, efficient code.
                </p>
              </div>

              <div className="grid sm:grid-cols-2 gap-4">
                <div className="bg-slate-50 p-6 rounded-xl">
                  <div className="flex items-center gap-2 mb-2">
                    <MapPin className="h-5 w-5 text-blue-600" />
                    <span className="font-semibold text-slate-800">Location</span>
                  </div>
                  <p className="text-slate-600">Link Road,Goregaon(W),Mumbai 400104, Maharashtra,India</p>
                </div>

                <div className="bg-slate-50 p-6 rounded-xl">
                  <div className="flex items-center gap-2 mb-2">
                    <Calendar className="h-5 w-5 text-blue-600" />
                    <span className="font-semibold text-slate-800">Experience</span>
                  </div>
                  <p className="text-slate-600">Fresher</p>
                </div>
              </div>
            </div>

            <div className="space-y-6">
              <div className="bg-gradient-to-br from-slate-800 to-slate-700 p-8 rounded-2xl text-white shadow-xl">
                <div className="flex items-center gap-3 mb-6">
                  <Heart className="h-6 w-6 text-red-400" />
                  <h3 className="text-xl font-semibold">What I Love</h3>
                </div>
                
                <div className="space-y-4">
                  <div className="flex items-center gap-3">
                    <div className="w-2 h-2 bg-blue-400 rounded-full"></div>
                    <span>Building responsive web applications</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <div className="w-2 h-2 bg-purple-400 rounded-full"></div>
                    <span>Learning new technologies and frameworks</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <div className="w-2 h-2 bg-green-400 rounded-full"></div>
                    <span>Solving complex problems with elegant solutions</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <div className="w-2 h-2 bg-yellow-400 rounded-full"></div>
                    <span>Collaborating with teams and sharing knowledge</span>
                  </div>
                </div>
              </div>

              <div className="bg-gradient-to-r from-blue-600 to-purple-600 p-1 rounded-2xl">
                <div className="bg-white p-6 rounded-xl">
                  <h4 className="text-lg font-semibold text-slate-800 mb-3">My Mission</h4>
                  <p className="text-slate-600 leading-relaxed">
                    To create innovative web solutions that provide exceptional user experiences
                    while maintaining clean, scalable, and maintainable code.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;