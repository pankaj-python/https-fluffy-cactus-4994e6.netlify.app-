import React from 'react';
import { ExternalLink, Github, Code, Globe, Database, Server } from 'lucide-react';

interface Project {
  id: number;
  title: string;
  description: string;
  image: string;
  technologies: string[];
  liveUrl?: string;
  githubUrl?: string;
  category: string;
}

const Projects: React.FC = () => {
  const projects: Project[] = [
    {
      id: 1,
      title: 'E-Commerce Platform',
      description: 'A full-stack e-commerce solution with user authentication, product management, and payment integration. Built with modern web technologies for optimal performance.',
      image: 'https://images.pexels.com/photos/230544/pexels-photo-230544.jpeg',
      technologies: ['HTML5', 'CSS3', 'JavaScript', 'Node.js', 'Express.js', 'SQL'],
      category: 'Full Stack'
    },
    {
      id: 2,
      title: 'Task Management App',
      description: 'A responsive task management application with real-time updates, drag-and-drop functionality, and team collaboration features.',
      image: 'https://images.pexels.com/photos/3153201/pexels-photo-3153201.jpeg',
      technologies: ['JavaScript', 'CSS3', 'HTML5', 'Node.js'],
      category: 'Web App'
    },
    {
      id: 3,
      title: 'Restaurant Website',
      description: 'A modern restaurant website with online booking system, menu display, and customer reviews. Optimized for mobile and desktop.',
      image: 'https://images.pexels.com/photos/262978/pexels-photo-262978.jpeg',
      technologies: ['HTML5', 'CSS3', 'JavaScript', 'SQL'],
      category: 'Frontend'
    },
    {
      id: 4,
      title: 'API Service Platform',
      description: 'A RESTful API service with authentication, rate limiting, and comprehensive documentation. Built for scalability and performance.',
      image: 'https://images.pexels.com/photos/1181263/pexels-photo-1181263.jpeg',
      technologies: ['Node.js', 'Express.js', 'SQL', 'JavaScript'],
      category: 'Backend'
    },
    {
      id: 5,
      title: 'Portfolio Dashboard',
      description: 'An interactive dashboard for tracking portfolio performance with real-time data visualization and analytics.',
      image: 'https://images.pexels.com/photos/590020/pexels-photo-590020.jpeg',
      technologies: ['JavaScript', 'HTML5', 'CSS3', 'Node.js'],
      category: 'Dashboard'
    },
    {
      id: 6,
      title: 'Blog Platform',
      description: 'A full-featured blogging platform with content management, user authentication, and social features.',
      image: 'https://images.pexels.com/photos/265667/pexels-photo-265667.jpeg',
      technologies: ['HTML5', 'CSS3', 'JavaScript', 'Node.js', 'Express.js', 'SQL'],
      category: 'Full Stack'
    }
  ];

  const getTechIcon = (tech: string) => {
    switch (tech.toLowerCase()) {
      case 'html5':
        return <Globe className="h-4 w-4" />;
      case 'css3':
        return <Code className="h-4 w-4" />;
      case 'javascript':
        return <Code className="h-4 w-4" />;
      case 'node.js':
        return <Server className="h-4 w-4" />;
      case 'express.js':
        return <Server className="h-4 w-4" />;
      case 'sql':
        return <Database className="h-4 w-4" />;
      default:
        return <Code className="h-4 w-4" />;
    }
  };

  return (
    <section id="projects" className="py-20 bg-white">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl sm:text-5xl font-bold text-slate-800 mb-4">
              Featured Projects
            </h2>
            <div className="w-24 h-1 bg-gradient-to-r from-blue-600 to-purple-600 mx-auto rounded-full mb-6"></div>
            <p className="text-xl text-slate-600 max-w-2xl mx-auto">
              Here are some of the projects I've worked on, showcasing my skills in
              full-stack development
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {projects.map((project, index) => (
              <div
                key={project.id}
                className="bg-white rounded-2xl shadow-lg overflow-hidden hover:shadow-2xl transition-all duration-300 transform hover:scale-105 group"
                style={{
                  animationDelay: `${index * 0.1}s`
                }}
              >
                <div className="relative overflow-hidden">
                  <img
                    src={project.image}
                    alt={project.title}
                    className="w-full h-48 object-cover group-hover:scale-110 transition-transform duration-300"
                  />
                  <div className="absolute top-4 left-4">
                    <span className="px-3 py-1 bg-blue-600 text-white text-sm rounded-full font-medium">
                      {project.category}
                    </span>
                  </div>
                  <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-20 transition-all duration-300 flex items-center justify-center opacity-0 group-hover:opacity-100">
                    <div className="flex gap-4">
                      <button className="p-3 bg-white rounded-full shadow-lg hover:bg-blue-50 transition-colors">
                        <ExternalLink className="h-5 w-5 text-blue-600" />
                      </button>
                      <button className="p-3 bg-white rounded-full shadow-lg hover:bg-slate-50 transition-colors">
                        <Github className="h-5 w-5 text-slate-800" />
                      </button>
                    </div>
                  </div>
                </div>

                <div className="p-6">
                  <h3 className="text-xl font-semibold text-slate-800 mb-3 group-hover:text-blue-600 transition-colors">
                    {project.title}
                  </h3>
                  <p className="text-slate-600 mb-4 line-clamp-3">
                    {project.description}
                  </p>

                  <div className="flex flex-wrap gap-2">
                    {project.technologies.map((tech) => (
                      <span
                        key={tech}
                        className="inline-flex items-center gap-1 px-3 py-1 bg-slate-100 text-slate-700 text-sm rounded-lg font-medium hover:bg-blue-100 hover:text-blue-700 transition-colors"
                      >
                        {getTechIcon(tech)}
                        {tech}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            ))}
          </div>

          <div className="text-center mt-16">
            <div className="bg-gradient-to-r from-blue-50 to-purple-50 p-8 rounded-2xl max-w-2xl mx-auto">
              <h3 className="text-2xl font-semibold text-slate-800 mb-4">
                Interested in Working Together?
              </h3>
              <p className="text-slate-600 mb-6">
                I'm always excited to take on new challenges and create amazing
                digital experiences. Let's discuss your next project!
              </p>
              <button
                onClick={() => {
                  const element = document.getElementById('contact');
                  element?.scrollIntoView({ behavior: 'smooth' });
                }}
                className="px-8 py-3 bg-gradient-to-r from-blue-600 to-purple-600 text-white rounded-lg font-semibold hover:from-blue-700 hover:to-purple-700 transform hover:scale-105 transition-all duration-200 shadow-lg"
              >
                Start a Conversation
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Projects;