import React, { useState, useEffect, useRef } from 'react';
import { Code2, Database, Globe, Server, Palette, Zap } from 'lucide-react';

interface Skill {
  name: string;
  level: number;
  icon: React.ReactNode;
  color: string;
}

const Skills: React.FC = () => {
  const [isVisible, setIsVisible] = useState(false);
  const sectionRef = useRef<HTMLDivElement>(null);

  const skills: Skill[] = [
    {
      name: 'HTML5',
      level: 95,
      icon: <Globe className="h-6 w-6" />,
      color: 'from-orange-500 to-red-500'
    },
    {
      name: 'CSS3',
      level: 90,
      icon: <Palette className="h-6 w-6" />,
      color: 'from-blue-500 to-cyan-500'
    },
    {
      name: 'JavaScript',
      level: 88,
      icon: <Code2 className="h-6 w-6" />,
      color: 'from-yellow-500 to-orange-500'
    },
    {
      name: 'Node.js',
      level: 85,
      icon: <Server className="h-6 w-6" />,
      color: 'from-green-500 to-emerald-500'
    },
    {
      name: 'Express.js',
      level: 82,
      icon: <Zap className="h-6 w-6" />,
      color: 'from-gray-600 to-gray-800'
    },
    {
      name: 'SQL',
      level: 80,
      icon: <Database className="h-6 w-6" />,
      color: 'from-purple-500 to-pink-500'
    }
  ];

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
        }
      },
      { threshold: 0.3 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => {
      if (sectionRef.current) {
        observer.unobserve(sectionRef.current);
      }
    };
  }, []);

  return (
    <section
      id="skills"
      ref={sectionRef}
      className="py-20 bg-gradient-to-br from-slate-50 to-blue-50"
    >
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl sm:text-5xl font-bold text-slate-800 mb-4">
              Technical Skills
            </h2>
            <div className="w-24 h-1 bg-gradient-to-r from-blue-600 to-purple-600 mx-auto rounded-full mb-6"></div>
            <p className="text-xl text-slate-600 max-w-2xl mx-auto">
              Here are the technologies I work with to bring ideas to life
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {skills.map((skill, index) => (
              <div
                key={skill.name}
                className="bg-white p-8 rounded-2xl shadow-lg hover:shadow-xl transition-all duration-300 transform hover:scale-105 group"
                style={{
                  animationDelay: `${index * 0.1}s`
                }}
              >
                <div className="flex items-center gap-4 mb-6">
                  <div className={`p-3 rounded-xl bg-gradient-to-r ${skill.color} text-white group-hover:scale-110 transition-transform duration-300`}>
                    {skill.icon}
                  </div>
                  <div>
                    <h3 className="text-xl font-semibold text-slate-800">{skill.name}</h3>
                    <p className="text-slate-600">{skill.level}% Proficiency</p>
                  </div>
                </div>

                <div className="relative">
                  <div className="w-full bg-slate-200 rounded-full h-3 overflow-hidden">
                    <div
                      className={`h-full bg-gradient-to-r ${skill.color} rounded-full transition-all duration-1000 ease-out`}
                      style={{
                        width: isVisible ? `${skill.level}%` : '0%'
                      }}
                    ></div>
                  </div>
                  <div
                    className={`absolute -top-8 bg-gradient-to-r ${skill.color} text-white px-2 py-1 rounded text-sm font-semibold transition-all duration-1000 ease-out`}
                    style={{
                      left: isVisible ? `${skill.level - 5}%` : '0%',
                      opacity: isVisible ? 1 : 0
                    }}
                  >
                    {skill.level}%
                  </div>
                </div>
              </div>
            ))}
          </div>

          <div className="mt-16 text-center">
            <div className="bg-white p-8 rounded-2xl shadow-lg max-w-2xl mx-auto">
              <h3 className="text-2xl font-semibold text-slate-800 mb-4">
                Always Learning
              </h3>
              <p className="text-slate-600 leading-relaxed">
                Technology evolves rapidly, and I'm committed to continuous learning.
                Currently exploring React, TypeScript, and cloud technologies to expand
                my skill set and deliver even better solutions.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Skills;