import React from 'react';
import { Code, Heart, Mail, Github, Linkedin, Twitter } from 'lucide-react';

const Footer: React.FC = () => {
  const currentYear = new Date().getFullYear();

  const socialLinks = [
    {
      name: 'Email',
      icon: <Mail className="h-5 w-5" />,
      url: 'mailto:pankaj.developer@gmail.com',
      color: 'hover:text-blue-400'
    },
    {
      name: 'GitHub',
      icon: <Github className="h-5 w-5" />,
      url: 'https://github.com/pankaj-python',
      color: 'hover:text-gray-400'
    },
    {
      name: 'LinkedIn',
      icon: <Linkedin className="h-5 w-5" />,
      url: 'https://www.linkedin.com/in/pankaj-upadhyay-736920250',
      color: 'hover:text-blue-500'
    },
    {
      name: 'Twitter',
      icon: <Twitter className="h-5 w-5" />,
      url: '#',
      color: 'hover:text-sky-400'
    }
  ];

  const scrollToTop = () => {
    window.scrollTo({
      top: 0,
      behavior: 'smooth'
    });
  };

  return (
    <footer className="bg-slate-900 text-white py-12">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-6xl mx-auto">
          {/* Main Footer Content */}
          <div className="grid md:grid-cols-3 gap-8 mb-8">
            {/* Brand Section */}
            <div className="space-y-4">
              <div className="flex items-center space-x-2">
                <Code className="h-8 w-8 text-blue-400" />
                <span className="text-2xl font-bold">Pankaj Upadhyay</span>
              </div>
              <p className="text-slate-400 leading-relaxed">
                Full Stack Developer passionate about creating exceptional digital
                experiences with clean, efficient code.
              </p>
              <div className="flex items-center space-x-1 text-slate-400">
                <span>Made with</span>
                <Heart className="h-4 w-4 text-red-500 fill-current" />
                <span>using React & TypeScript</span>
              </div>
            </div>

            {/* Quick Links */}
            <div className="space-y-4">
              <h3 className="text-lg font-semibold text-white">Quick Links</h3>
              <nav className="space-y-2">
                {['Home', 'About', 'Skills', 'Projects', 'Contact'].map((item) => (
                  <button
                    key={item}
                    onClick={() => {
                      const element = document.getElementById(item.toLowerCase());
                      element?.scrollIntoView({ behavior: 'smooth' });
                    }}
                    className="block text-slate-400 hover:text-blue-400 transition-colors duration-200"
                  >
                    {item}
                  </button>
                ))}
              </nav>
            </div>

            {/* Contact Info */}
            <div className="space-y-4">
              <h3 className="text-lg font-semibold text-white">Get In Touch</h3>
              <div className="space-y-3">
                <div className="flex items-center space-x-3">
                  <Mail className="h-5 w-5 text-blue-400" />
                  <a
                    href="mailto:pankaj.developer@gmail.com"
                    className="text-slate-400 hover:text-blue-400 transition-colors duration-200"
                  >
                    pankaj.developer@gmail.com
                  </a>
                </div>
                <p className="text-slate-400">
                  Available for freelance opportunities and full-time positions.
                </p>
              </div>
            </div>
          </div>

          {/* Social Links & Copyright */}
          <div className="border-t border-slate-800 pt-8 flex flex-col sm:flex-row justify-between items-center space-y-4 sm:space-y-0">
            <div className="flex items-center space-x-6">
              {socialLinks.map((link) => (
                <a
                  key={link.name}
                  href={link.url}
                  className={`text-slate-400 ${link.color} transition-colors duration-200 transform hover:scale-110`}
                  aria-label={link.name}
                >
                  {link.icon}
                </a>
              ))}
            </div>

            <div className="flex items-center space-x-4">
              <p className="text-slate-400 text-sm">
                © {currentYear} Pankaj Upadhyay. All rights reserved.
              </p>
              <button
                onClick={scrollToTop}
                className="p-2 bg-slate-800 hover:bg-slate-700 rounded-lg transition-colors duration-200 transform hover:scale-110"
                aria-label="Scroll to top"
              >
                <Code className="h-4 w-4 text-blue-400" />
              </button>
            </div>
          </div>

          {/* Fun Footer Message */}
          <div className="mt-8 text-center">
            <p className="text-slate-500 text-sm">
              This portfolio was crafted with attention to detail and a passion for great UX ✨
            </p>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;